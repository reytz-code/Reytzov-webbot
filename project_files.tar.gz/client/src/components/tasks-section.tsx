import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface TasksSectionProps {
  user: any;
}

export default function TasksSection({ user }: TasksSectionProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get tasks
  const { data: tasks = [], isLoading: tasksLoading } = useQuery({
    queryKey: ['/api/tasks'],
  });

  // Get user tasks
  const { data: userTasks = [], isLoading: userTasksLoading } = useQuery({
    queryKey: ['/api/user', user?.id, 'tasks'],
    enabled: !!user?.id,
  });

  // Complete task mutation
  const completeTaskMutation = useMutation({
    mutationFn: async ({ taskId, userId }: { taskId: string; userId: string }) => {
      const response = await apiRequest('POST', `/api/tasks/${taskId}/complete`, { userId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Задание выполнено!",
        description: "Награда зачислена на ваш счет",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось завершить задание",
        variant: "destructive",
      });
    },
  });

  const getTaskIcon = (type: string) => {
    switch (type) {
      case 'channel_subscribe': return '📢';
      case 'referral': return '👥';
      case 'case_opening': return '🎁';
      default: return '✅';
    }
  };

  const getTaskProgress = (task: any, userTask: any) => {
    if (userTask?.completed) return 100;
    
    switch (task.type) {
      case 'referral':
        const referrals = user?.totalReferrals || 0;
        return Math.min((referrals / task.targetValue) * 100, 100);
      case 'case_opening':
        const casesOpened = user?.casesOpened || 0;
        return Math.min((casesOpened / task.targetValue) * 100, 100);
      default:
        return userTask?.progress || 0;
    }
  };

  const getProgressText = (task: any, userTask: any) => {
    if (userTask?.completed) return 'Выполнено';
    
    switch (task.type) {
      case 'referral':
        const referrals = user?.totalReferrals || 0;
        return `${Math.min(referrals, task.targetValue)}/${task.targetValue}`;
      case 'case_opening':
        const casesOpened = user?.casesOpened || 0;
        return `${Math.min(casesOpened, task.targetValue)}/${task.targetValue}`;
      default:
        return userTask ? `${userTask.progress}/${task.targetValue}` : '0/1';
    }
  };

  const canCompleteTask = (task: any, userTask: any) => {
    if (userTask?.completed) return false;
    
    switch (task.type) {
      case 'referral':
        return (user?.totalReferrals || 0) >= task.targetValue;
      case 'case_opening':
        return (user?.casesOpened || 0) >= task.targetValue;
      case 'channel_subscribe':
        return !userTask; // Can attempt if not started
      default:
        return false;
    }
  };

  const handleTaskClick = (task: any) => {
    const userTask = userTasks.find((ut: any) => ut.taskId === task.id);
    
    if (task.type === 'channel_subscribe' && task.url) {
      // Open channel link
      window.open(task.url, '_blank');
      // Allow user to mark as completed after opening
      setTimeout(() => {
        if (confirm('Вы подписались на канал?')) {
          completeTaskMutation.mutate({ taskId: task.id, userId: user.id });
        }
      }, 2000);
    } else if (canCompleteTask(task, userTask)) {
      completeTaskMutation.mutate({ taskId: task.id, userId: user.id });
    }
  };

  if (tasksLoading || userTasksLoading) {
    return (
      <div className="p-4 space-y-4">
        <h2 className="text-xl font-bold">Задания</h2>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-muted rounded-lg animate-pulse"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded animate-pulse"></div>
                    <div className="h-3 bg-muted rounded w-3/4 animate-pulse"></div>
                  </div>
                  <div className="w-20 h-8 bg-muted rounded animate-pulse"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold" data-testid="tasks-title">Задания</h2>
      
      {/* Tasks List */}
      <div className="space-y-3">
        {tasks.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-muted-foreground">Пока нет доступных заданий</p>
            </CardContent>
          </Card>
        ) : (
          tasks.map((task: any) => {
            const userTask = userTasks.find((ut: any) => ut.taskId === task.id);
            const progress = getTaskProgress(task, userTask);
            const isCompleted = userTask?.completed;
            const canComplete = canCompleteTask(task, userTask);
            
            return (
              <Card key={task.id} data-testid={`task-${task.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    {/* Task Icon */}
                    <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center">
                      <span className="text-2xl">{getTaskIcon(task.type)}</span>
                    </div>
                    
                    {/* Task Info */}
                    <div className="flex-1">
                      <h4 className="font-medium" data-testid={`task-title-${task.id}`}>
                        {task.title}
                      </h4>
                      <p className="text-sm text-muted-foreground" data-testid={`task-description-${task.id}`}>
                        {task.description}
                      </p>
                      
                      {/* Reward */}
                      <div className="flex items-center space-x-1 mt-1">
                        <span className="text-yellow-400">⭐</span>
                        <span className="text-sm font-medium" data-testid={`task-reward-${task.id}`}>
                          {task.reward} Stars
                        </span>
                      </div>
                      
                      {/* Progress for multi-step tasks */}
                      {(task.type === 'referral' || task.type === 'case_opening') && (
                        <div className="mt-2">
                          <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                            <span>Прогресс</span>
                            <span data-testid={`task-progress-text-${task.id}`}>
                              {getProgressText(task, userTask)}
                            </span>
                          </div>
                          <Progress value={progress} className="h-2" data-testid={`task-progress-${task.id}`} />
                        </div>
                      )}
                    </div>
                    
                    {/* Action Button */}
                    <div className="ml-auto">
                      {isCompleted ? (
                        <Badge variant="secondary" className="bg-green-100 text-green-700" data-testid={`task-completed-${task.id}`}>
                          ✓ Выполнено
                        </Badge>
                      ) : canComplete ? (
                        <Button 
                          size="sm"
                          onClick={() => handleTaskClick(task)}
                          disabled={completeTaskMutation.isPending}
                          data-testid={`task-complete-button-${task.id}`}
                        >
                          {completeTaskMutation.isPending ? 'Загрузка...' : 'Получить'}
                        </Button>
                      ) : task.type === 'channel_subscribe' ? (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleTaskClick(task)}
                          data-testid={`task-action-button-${task.id}`}
                        >
                          Выполнить
                        </Button>
                      ) : (
                        <Badge variant="outline" data-testid={`task-in-progress-${task.id}`}>
                          В процессе
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Info */}
      <Card>
        <CardContent className="pt-6">
          <h4 className="font-medium mb-2">💡 Как получить Stars</h4>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>• Выполняйте задания и получайте Stars</p>
            <p>• Приглашайте друзей через реферальную ссылку</p>
            <p>• Активно участвуйте в игре</p>
            <p>• Подписывайтесь на наши каналы</p>
          </div>
        </CardContent>
      </Card>

      {/* Current Balance */}
      <Card>
        <CardContent className="pt-6">
          <div className="text-center">
            <p className="text-muted-foreground text-sm mb-2">Ваши Stars</p>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-2xl font-bold" data-testid="current-stars">{user?.stars || 0}</span>
              <span className="text-yellow-400">⭐</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Обменивайте на re:coin в профиле
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
