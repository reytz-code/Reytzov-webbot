import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface CasesSectionProps {
  cases: any[];
  onOpenCase: (caseId: string) => void;
  user: any;
}

export default function CasesSection({ cases, onOpenCase, user }: CasesSectionProps) {
  const { toast } = useToast();

  const dailyCase = cases.find(c => c.isDaily);
  const regularCases = cases.filter(c => !c.isDaily).sort((a, b) => a.cost - b.cost);

  // Check if daily case is available
  const { data: canUseDailyCase = true } = useQuery({
    queryKey: ['/api/user', user?.id, 'daily-case'],
    enabled: !!user?.id && !!dailyCase,
    refetchInterval: 60000, // Check every minute
  });

  const getCaseIcon = (cost: number) => {
    if (cost === 0) return '🎁';
    if (cost <= 25) return '🎯';
    if (cost <= 100) return '🎪';
    if (cost <= 250) return '💎';
    if (cost <= 500) return '🏆';
    return '👑';
  };

  const getCaseGradient = (cost: number) => {
    if (cost === 0) return 'from-green-600 to-emerald-500';
    if (cost <= 25) return 'from-yellow-400 to-orange-500';
    if (cost <= 100) return 'from-purple-400 to-pink-500';
    if (cost <= 250) return 'from-blue-400 to-cyan-500';
    if (cost <= 500) return 'from-red-400 to-orange-500';
    return 'from-yellow-500 via-red-500 to-pink-500';
  };

  const getCaseGlow = (cost: number) => {
    if (cost === 0) return 'glow-effect';
    if (cost >= 1000) return 'gold-glow';
    if (cost >= 250) return 'purple-glow';
    return 'glow-effect';
  };

  const handleCaseClick = (caseItem: any) => {
    // Check if user has enough recoins for non-daily cases
    if (!caseItem.isDaily && user && user.recoins < caseItem.cost) {
      toast({
        title: "Недостаточно re:coin",
        description: `Для открытия этого кейса нужно ${caseItem.cost} re:coin. У вас: ${user.recoins}`,
        variant: "destructive",
      });
      return;
    }

    // Check daily case availability
    if (caseItem.isDaily && !canUseDailyCase) {
      toast({
        title: "Ежедневный кейс недоступен",
        description: "Возвращайтесь завтра за новым бесплатным кейсом!",
        variant: "destructive",
      });
      return;
    }

    onOpenCase(caseItem.id);
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold" data-testid="cases-title">Кейсы</h2>

      {/* Daily Case */}
      {dailyCase && (
        <div className={`bg-gradient-to-r ${getCaseGradient(0)} rounded-lg p-4 case-item ${getCaseGlow(0)}`}>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-white font-bold">Ежедневный кейс</h3>
            <Badge variant="secondary" className="bg-white/20 text-white">
              {canUseDailyCase ? 'ДОСТУПЕН' : 'ИСПОЛЬЗОВАН'}
            </Badge>
          </div>
          <p className="text-white/80 text-sm mb-3">От 1 до 25 re:coin</p>
          <Button 
            className="w-full bg-white text-green-600 hover:bg-white/90"
            onClick={() => handleCaseClick(dailyCase)}
            disabled={!canUseDailyCase}
            data-testid="button-open-daily-case"
          >
            {canUseDailyCase ? 'Открыть бесплатно' : 'Использован сегодня'}
          </Button>
        </div>
      )}

      {/* Regular Cases Grid */}
      <div className="grid grid-cols-2 gap-3">
        {regularCases.map((caseItem: any) => (
          <Card 
            key={caseItem.id} 
            className={`case-item cursor-pointer hover:shadow-lg transition-all duration-300 ${getCaseGlow(caseItem.cost)}`}
            onClick={() => handleCaseClick(caseItem)}
            data-testid={`case-card-${caseItem.id}`}
          >
            <CardContent className="p-3">
              <div className="text-center mb-3">
                <div className={`w-16 h-16 mx-auto bg-gradient-to-br ${getCaseGradient(caseItem.cost)} rounded-lg flex items-center justify-center text-2xl mb-2`}>
                  {getCaseIcon(caseItem.cost)}
                </div>
                <h4 className="font-medium text-sm" data-testid={`case-name-${caseItem.id}`}>
                  {caseItem.name}
                </h4>
              </div>
              
              <div className="text-center mb-3">
                <div className="flex items-center justify-center space-x-1">
                  <span className="text-primary">🪙</span>
                  <span className="font-bold" data-testid={`case-cost-${caseItem.id}`}>
                    {caseItem.cost}
                  </span>
                </div>
              </div>
              
              <Button 
                className={`w-full text-sm ${
                  user && user.recoins >= caseItem.cost 
                    ? 'bg-primary text-primary-foreground hover:bg-primary/90' 
                    : 'bg-muted text-muted-foreground cursor-not-allowed'
                }`}
                size="sm"
                disabled={!user || user.recoins < caseItem.cost}
                data-testid={`button-open-case-${caseItem.id}`}
              >
                {user && user.recoins >= caseItem.cost ? 'Открыть' : 'Недостаточно 🪙'}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Special Ultimate Case */}
      {regularCases.find(c => c.cost >= 1000) && (
        <div className="bg-gradient-to-r from-yellow-500 via-red-500 to-pink-500 rounded-lg p-4 case-item gold-glow">
          <div className="text-center mb-3">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-yellow-300 to-yellow-600 rounded-lg flex items-center justify-center text-3xl mb-2">
              👑
            </div>
            <h3 className="text-white font-bold text-lg">Королевский кейс</h3>
            <p className="text-white/80 text-sm">Максимальные призы и подарки</p>
          </div>
          <div className="text-center mb-4">
            <div className="flex items-center justify-center space-x-1">
              <span className="text-yellow-300 text-xl">🪙</span>
              <span className="font-bold text-white text-xl">1000</span>
            </div>
          </div>
          <Button 
            className="w-full bg-white text-yellow-600 py-3 rounded-lg font-bold hover:bg-white/90"
            onClick={() => {
              const ultimateCase = regularCases.find(c => c.cost >= 1000);
              if (ultimateCase) handleCaseClick(ultimateCase);
            }}
            disabled={!user || user.recoins < 1000}
            data-testid="button-open-ultimate-case"
          >
            {user && user.recoins >= 1000 ? 'Открыть Королевский' : `Нужно ${1000 - (user?.recoins || 0)} 🪙`}
          </Button>
        </div>
      )}

      {/* Balance Info */}
      <Card>
        <CardContent className="pt-6">
          <div className="text-center">
            <p className="text-muted-foreground text-sm mb-2">Ваш баланс</p>
            <div className="flex items-center justify-center space-x-2">
              <span className="text-2xl font-bold" data-testid="current-balance">{user?.recoins || 0}</span>
              <span className="text-primary">🪙</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              1 ⭐ = 5 🪙 re:coin
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Info about prizes */}
      <Card>
        <CardContent className="pt-6">
          <h4 className="font-medium mb-2">💡 Подсказка</h4>
          <p className="text-sm text-muted-foreground">
            В кейсах можно выиграть re:coin или реальные подарки! 
            Подарки имеют уникальные номера и выдаются администратором.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
