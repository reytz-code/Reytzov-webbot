import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function LeadersSection() {
  const [activeTab, setActiveTab] = useState<'recoins' | 'cases'>('recoins');

  // Get leaderboard data
  const { data: leaders = [], isLoading } = useQuery({
    queryKey: ['/api/leaderboard', activeTab],
  });

  const getRankIcon = (position: number) => {
    switch (position) {
      case 1: return '🥇';
      case 2: return '🥈';
      case 3: return '🥉';
      default: return `#${position}`;
    }
  };

  const getRankColor = (position: number) => {
    switch (position) {
      case 1: return 'bg-yellow-500 text-yellow-50';
      case 2: return 'bg-gray-400 text-gray-50';
      case 3: return 'bg-amber-600 text-amber-50';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-xl font-bold" data-testid="leaders-title">Лидеры</h2>

      {/* Leaderboard Tabs */}
      <div className="flex bg-muted rounded-lg p-1">
        <Button
          variant={activeTab === 'recoins' ? 'default' : 'ghost'}
          className="flex-1 text-sm"
          onClick={() => setActiveTab('recoins')}
          data-testid="tab-recoins"
        >
          По re:coin
        </Button>
        <Button
          variant={activeTab === 'cases' ? 'default' : 'ghost'}
          className="flex-1 text-sm"
          onClick={() => setActiveTab('cases')}
          data-testid="tab-cases"
        >
          По кейсам
        </Button>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-muted rounded-full animate-pulse"></div>
                  <div className="w-10 h-10 bg-muted rounded-full animate-pulse"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded animate-pulse"></div>
                    <div className="h-3 bg-muted rounded w-3/4 animate-pulse"></div>
                  </div>
                  <div className="w-16 h-6 bg-muted rounded animate-pulse"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Leaders List */}
      {!isLoading && (
        <div className="space-y-3">
          {leaders.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-muted-foreground">Пока нет данных для лидерборда</p>
              </CardContent>
            </Card>
          ) : (
            leaders.map((leader: any, index: number) => (
              <Card key={leader.id || index} data-testid={`leader-${index + 1}`}>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    {/* Rank */}
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${getRankColor(index + 1)}`}>
                      {index < 3 ? getRankIcon(index + 1) : index + 1}
                    </div>

                    {/* Avatar */}
                    <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
                      <span className="text-accent-foreground font-bold text-sm" data-testid={`leader-initials-${index + 1}`}>
                        {leader.firstName?.[0] || 'U'}{leader.lastName?.[0] || ''}
                      </span>
                    </div>

                    {/* User Info */}
                    <div className="flex-1">
                      <h4 className="font-medium" data-testid={`leader-name-${index + 1}`}>
                        {leader.firstName} {leader.lastName || ''}
                      </h4>
                      <p className="text-sm text-muted-foreground" data-testid={`leader-username-${index + 1}`}>
                        @{leader.username || 'anonymous'}
                      </p>
                    </div>

                    {/* Score */}
                    <div className="text-right">
                      <div className="font-bold" data-testid={`leader-score-${index + 1}`}>
                        {activeTab === 'recoins' 
                          ? (leader.recoins || 0).toLocaleString() 
                          : (leader.casesOpened || 0).toLocaleString()
                        }
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {activeTab === 'recoins' ? 're:coin' : 'кейсов'}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}

      {/* Info */}
      <Card>
        <CardContent className="pt-6">
          <h4 className="font-medium mb-2">🏆 Лидерборд</h4>
          <p className="text-sm text-muted-foreground">
            {activeTab === 'recoins' 
              ? 'Рейтинг игроков по количеству накопленных re:coin за все время.'
              : 'Рейтинг игроков по количеству открытых кейсов за все время.'
            }
          </p>
        </CardContent>
      </Card>

      {/* Achievement Info */}
      <Card>
        <CardContent className="pt-6">
          <h4 className="font-medium mb-3">🎯 Достижения</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">🥇 1-е место</span>
              <Badge variant="secondary">Золотая медаль</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">🥈 2-е место</span>
              <Badge variant="secondary">Серебряная медаль</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">🥉 3-е место</span>
              <Badge variant="secondary">Бронзовая медаль</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
