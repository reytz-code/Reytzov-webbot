import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface ProfileSectionProps {
  user: any;
}

export default function ProfileSection({ user }: ProfileSectionProps) {
  const [promoCode, setPromoCode] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Use promo code mutation
  const usePromoMutation = useMutation({
    mutationFn: async ({ userId, code }: { userId: string; code: string }) => {
      const response = await apiRequest('POST', '/api/promo/use', { userId, code });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      toast({
        title: "Промокод активирован!",
        description: `Получено ${data.user?.recoins || 0} re:coin`,
      });
      setPromoCode("");
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Неверный промокод",
        variant: "destructive",
      });
    },
  });

  // Purchase re:coin with Telegram Stars mutation
  const purchaseRecoinsMutation = useMutation({
    mutationFn: async ({ userId, starsAmount }: { userId: string; starsAmount: number }) => {
      const response = await apiRequest('POST', '/api/recoins/purchase', { userId, starsAmount });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      toast({
        title: "re:coin получены!",
        description: `Получено ${data.recoinsPurchased || 0} re:coin за ${data.starsSpent || 0} ⭐`,
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось приобрести re:coin",
        variant: "destructive",
      });
    },
  });

  const handlePromoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoCode.trim() || !user?.id) return;
    usePromoMutation.mutate({ userId: user.id, code: promoCode.trim() });
  };

  const handleTopUp = () => {
    if (!user?.id) return;
    // Purchase 50 re:coin for 10 Telegram Stars (1 star = 5 re:coin)
    purchaseRecoinsMutation.mutate({ userId: user.id, starsAmount: 10 });
  };

  const handleReferralShare = () => {
    const referralLink = `https://t.me/your_bot?start=${user?.referralCode || user?.telegramId}`;
    
    if (navigator.share) {
      navigator.share({
        title: 'Easy Gift - Игра в кейсы',
        text: 'Присоединяйся к Easy Gift! Открывай кейсы и получай призы!',
        url: referralLink,
      });
    } else {
      navigator.clipboard.writeText(referralLink);
      toast({
        title: "Ссылка скопирована!",
        description: "Реферальная ссылка скопирована в буфер обмена",
      });
    }

    // Notify Telegram
    if (window.Telegram?.WebApp) {
      window.Telegram.WebApp.sendData(JSON.stringify({
        action: 'referral_share',
        referralCode: user?.referralCode || user?.telegramId
      }));
    }
  };

  if (!user) {
    return (
      <div className="p-4 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Загрузка профиля...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      {/* User Info Card */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
              <span className="text-accent-foreground font-bold text-xl" data-testid="profile-initials">
                {user.firstName?.[0] || 'U'}{user.lastName?.[0] || ''}
              </span>
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-lg" data-testid="profile-name">
                {user.firstName} {user.lastName}
              </h3>
              <p className="text-muted-foreground text-sm" data-testid="profile-telegram-id">
                #{user.telegramId}
              </p>
              <p className="text-xs text-muted-foreground" data-testid="profile-username">
                @{user.username || 'не указан'}
              </p>
            </div>
            <div className="w-4 h-4 bg-blue-500 rounded-full"></div>
          </div>
        </CardContent>
      </Card>

      {/* Balance Section */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-muted-foreground">Баланс</span>
            <Button 
              onClick={handleTopUp}
              disabled={purchaseRecoinsMutation.isPending}
              className="text-sm"
              data-testid="button-top-up"
            >
              {purchaseRecoinsMutation.isPending ? 'Загрузка...' : 'Купить за ⭐ Stars'}
            </Button>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2">
              <span className="text-3xl font-bold" data-testid="balance-recoins">{user.recoins || 0}</span>
              <span className="text-primary text-2xl">🪙</span>
            </div>
            <p className="text-sm text-muted-foreground">re:coin</p>
          </div>
        </CardContent>
      </Card>

      {/* Promo Code Section */}
      <Card>
        <CardContent className="pt-6">
          <h4 className="font-medium mb-3">Секретный код</h4>
          <form onSubmit={handlePromoSubmit} className="space-y-3">
            <Input 
              type="text" 
              placeholder="Введите промокод..." 
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              disabled={usePromoMutation.isPending}
              data-testid="input-promo-code"
            />
            <Button 
              type="submit" 
              className="w-full" 
              disabled={usePromoMutation.isPending || !promoCode.trim()}
              data-testid="button-activate-promo"
            >
              {usePromoMutation.isPending ? 'Активация...' : 'Активировать'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Referral System */}
      <Card>
        <CardContent className="pt-6">
          <h4 className="font-medium mb-3">Реферальная система</h4>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-center">
                <div className="font-bold text-lg" data-testid="referral-count">{user.totalReferrals || 0}</div>
                <div className="text-muted-foreground">Приглашено</div>
              </div>
              <div className="text-center">
                <div className="font-bold text-lg text-green-400" data-testid="referral-earnings">
                  {(user.totalReferrals || 0) * 25}
                </div>
                <div className="text-muted-foreground">Заработано re:coin</div>
              </div>
            </div>
            <Button 
              onClick={handleReferralShare}
              className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/80"
              data-testid="button-invite-friend"
            >
              Пригласить друга (+25 re:coin)
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <Card>
        <CardContent className="pt-6">
          <h4 className="font-medium mb-3">Статистика</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="text-center">
              <div className="font-bold text-lg" data-testid="stat-cases-opened">{user.casesOpened || 0}</div>
              <div className="text-muted-foreground">Кейсов открыто</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-lg">{user.totalReferrals || 0}</div>
              <div className="text-muted-foreground">Рефералов</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Links */}
      <div className="space-y-2">
        <a 
          href="https://t.me/budkareytzov" 
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-between bg-card rounded-lg p-3 border border-border hover:bg-accent/50 transition-colors"
          data-testid="link-channel"
        >
          <span>📢 Наш канал</span>
          <span className="text-muted-foreground">→</span>
        </a>
        <a 
          href="https://t.me/oxoxece" 
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-between bg-card rounded-lg p-3 border border-border hover:bg-accent/50 transition-colors"
          data-testid="link-support"
        >
          <span>💬 Поддержка</span>
          <span className="text-muted-foreground">→</span>
        </a>
      </div>
    </div>
  );
}
