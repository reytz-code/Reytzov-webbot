interface BottomNavigationProps {
  activeSection: 'profile' | 'cases' | 'leaders' | 'tasks';
  onSectionChange: (section: 'profile' | 'cases' | 'leaders' | 'tasks') => void;
}

export default function BottomNavigation({ activeSection, onSectionChange }: BottomNavigationProps) {
  const sections = [
    { id: 'profile', icon: '👤', label: 'Профиль' },
    { id: 'cases', icon: '📦', label: 'Кейсы' },
    { id: 'leaders', icon: '🏆', label: 'Лидеры' },
    { id: 'tasks', icon: '✅', label: 'Задания' },
  ] as const;

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-card border-t border-border z-20" data-testid="bottom-navigation">
      <div className="flex items-center justify-around py-2">
        {sections.map((section) => (
          <button
            key={section.id}
            className={`flex flex-col items-center py-2 px-3 transition-colors ${
              activeSection === section.id 
                ? 'text-primary' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
            onClick={() => onSectionChange(section.id)}
            data-testid={`nav-${section.id}`}
          >
            <span className="text-xl mb-1">{section.icon}</span>
            <span className="text-xs font-medium">{section.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
