import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Users, Package, Trophy, Plus } from "lucide-react";

export default function Admin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get cases
  const { data: cases = [] } = useQuery({
    queryKey: ['/api/cases'],
  });

  // Get tasks
  const { data: tasks = [] } = useQuery({
    queryKey: ['/api/tasks'],
  });

  // Create case mutation
  const createCaseMutation = useMutation({
    mutationFn: async (caseData: any) => {
      const response = await apiRequest('POST', '/api/admin/cases', caseData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cases'] });
      toast({ title: "Кейс создан", description: "Новый кейс успешно создан" });
    },
    onError: () => {
      toast({ title: "Ошибка", description: "Не удалось создать кейс", variant: "destructive" });
    },
  });

  // Create prize mutation
  const createPrizeMutation = useMutation({
    mutationFn: async (prizeData: any) => {
      const response = await apiRequest('POST', '/api/admin/prizes', prizeData);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Приз создан", description: "Новый приз успешно создан" });
    },
    onError: () => {
      toast({ title: "Ошибка", description: "Не удалось создать приз", variant: "destructive" });
    },
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (taskData: any) => {
      const response = await apiRequest('POST', '/api/admin/tasks', taskData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({ title: "Задание создано", description: "Новое задание успешно создано" });
    },
    onError: () => {
      toast({ title: "Ошибка", description: "Не удалось создать задание", variant: "destructive" });
    },
  });

  const [newCase, setNewCase] = useState({
    name: '',
    cost: 0,
    image: '',
    isDaily: false,
  });

  const [newPrize, setNewPrize] = useState({
    caseId: '',
    name: '',
    type: 'recoins',
    value: 0,
    giftNumber: 1,
    chance: 10,
    image: '',
  });

  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    type: 'channel_subscribe',
    url: '',
    targetValue: 1,
    reward: 50,
  });

  const handleCreateCase = (e: React.FormEvent) => {
    e.preventDefault();
    createCaseMutation.mutate(newCase);
    setNewCase({ name: '', cost: 0, image: '', isDaily: false });
  };

  const handleCreatePrize = (e: React.FormEvent) => {
    e.preventDefault();
    createPrizeMutation.mutate(newPrize);
    setNewPrize({
      caseId: '',
      name: '',
      type: 'recoins',
      value: 0,
      giftNumber: 1,
      chance: 10,
      image: '',
    });
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    createTaskMutation.mutate(newTask);
    setNewTask({
      title: '',
      description: '',
      type: 'channel_subscribe',
      url: '',
      targetValue: 1,
      reward: 50,
    });
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-2 mb-6">
          <Shield className="h-6 w-6 text-destructive" />
          <h1 className="text-2xl font-bold" data-testid="admin-title">Админ панель</h1>
          <span className="bg-destructive text-destructive-foreground px-2 py-1 rounded text-xs">ADMIN</span>
        </div>

        <Tabs defaultValue="stats" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="stats" data-testid="tab-stats">Статистика</TabsTrigger>
            <TabsTrigger value="cases" data-testid="tab-cases">Кейсы</TabsTrigger>
            <TabsTrigger value="tasks" data-testid="tab-tasks">Задания</TabsTrigger>
            <TabsTrigger value="promo" data-testid="tab-promo">Промокоды</TabsTrigger>
          </TabsList>

          {/* Statistics */}
          <TabsContent value="stats" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Пользователей</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-users">1,247</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Кейсов открыто</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-cases">8,932</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Подарков выдано</CardTitle>
                  <Trophy className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-gifts">156</div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Активных заданий</CardTitle>
                  <Plus className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-tasks">{tasks.length}</div>
                </CardContent>
              </Card>
            </div>

            {/* Recent notifications */}
            <Card>
              <CardHeader>
                <CardTitle>Последние уведомления</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between" data-testid="notification-1">
                    <span>Пользователь @user123 получил подарок #252</span>
                    <span className="text-muted-foreground">2м назад</span>
                  </div>
                  <div className="flex justify-between" data-testid="notification-2">
                    <span>Новый пользователь зарегистрирован</span>
                    <span className="text-muted-foreground">15м назад</span>
                  </div>
                  <div className="flex justify-between" data-testid="notification-3">
                    <span>Кейс "Легендарный" открыт 50 раз</span>
                    <span className="text-muted-foreground">1ч назад</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cases Management */}
          <TabsContent value="cases" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Create Case */}
              <Card>
                <CardHeader>
                  <CardTitle>Создать кейс</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreateCase} className="space-y-4">
                    <div>
                      <Label htmlFor="case-name">Название</Label>
                      <Input
                        id="case-name"
                        value={newCase.name}
                        onChange={(e) => setNewCase({ ...newCase, name: e.target.value })}
                        placeholder="Название кейса"
                        data-testid="input-case-name"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="case-cost">Стоимость (re:coin)</Label>
                      <Input
                        id="case-cost"
                        type="number"
                        value={newCase.cost}
                        onChange={(e) => setNewCase({ ...newCase, cost: parseInt(e.target.value) })}
                        placeholder="0"
                        data-testid="input-case-cost"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="case-image">URL изображения</Label>
                      <Input
                        id="case-image"
                        value={newCase.image}
                        onChange={(e) => setNewCase({ ...newCase, image: e.target.value })}
                        placeholder="https://..."
                        data-testid="input-case-image"
                      />
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="case-daily"
                        checked={newCase.isDaily}
                        onChange={(e) => setNewCase({ ...newCase, isDaily: e.target.checked })}
                        data-testid="checkbox-case-daily"
                      />
                      <Label htmlFor="case-daily">Ежедневный кейс</Label>
                    </div>
                    
                    <Button type="submit" className="w-full" data-testid="button-create-case">
                      Создать кейс
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Create Prize */}
              <Card>
                <CardHeader>
                  <CardTitle>Создать приз</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreatePrize} className="space-y-4">
                    <div>
                      <Label htmlFor="prize-case">Кейс</Label>
                      <Select 
                        value={newPrize.caseId} 
                        onValueChange={(value) => setNewPrize({ ...newPrize, caseId: value })}
                      >
                        <SelectTrigger data-testid="select-prize-case">
                          <SelectValue placeholder="Выберите кейс" />
                        </SelectTrigger>
                        <SelectContent>
                          {cases.map((caseItem: any) => (
                            <SelectItem key={caseItem.id} value={caseItem.id}>
                              {caseItem.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="prize-name">Название приза</Label>
                      <Input
                        id="prize-name"
                        value={newPrize.name}
                        onChange={(e) => setNewPrize({ ...newPrize, name: e.target.value })}
                        placeholder="Название приза"
                        data-testid="input-prize-name"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="prize-type">Тип приза</Label>
                      <Select 
                        value={newPrize.type} 
                        onValueChange={(value) => setNewPrize({ ...newPrize, type: value })}
                      >
                        <SelectTrigger data-testid="select-prize-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="recoins">re:coin</SelectItem>
                          <SelectItem value="gift">Подарок</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {newPrize.type === 'recoins' ? (
                      <div>
                        <Label htmlFor="prize-value">Количество re:coin</Label>
                        <Input
                          id="prize-value"
                          type="number"
                          value={newPrize.value}
                          onChange={(e) => setNewPrize({ ...newPrize, value: parseInt(e.target.value) })}
                          placeholder="0"
                          data-testid="input-prize-value"
                        />
                      </div>
                    ) : (
                      <div>
                        <Label htmlFor="prize-gift-number">Номер подарка</Label>
                        <Input
                          id="prize-gift-number"
                          type="number"
                          value={newPrize.giftNumber}
                          onChange={(e) => setNewPrize({ ...newPrize, giftNumber: parseInt(e.target.value) })}
                          placeholder="1"
                          data-testid="input-prize-gift-number"
                        />
                      </div>
                    )}
                    
                    <div>
                      <Label htmlFor="prize-chance">Шанс выпадения (%)</Label>
                      <Input
                        id="prize-chance"
                        type="number"
                        step="0.01"
                        value={newPrize.chance}
                        onChange={(e) => setNewPrize({ ...newPrize, chance: parseFloat(e.target.value) })}
                        placeholder="10"
                        data-testid="input-prize-chance"
                      />
                    </div>
                    
                    <Button type="submit" className="w-full" data-testid="button-create-prize">
                      Создать приз
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Existing Cases */}
            <Card>
              <CardHeader>
                <CardTitle>Существующие кейсы</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {cases.map((caseItem: any) => (
                    <div key={caseItem.id} className="border rounded-lg p-4" data-testid={`case-item-${caseItem.id}`}>
                      <h4 className="font-medium">{caseItem.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {caseItem.isDaily ? 'Ежедневный' : `${caseItem.cost} re:coin`}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        ID: {caseItem.id}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tasks Management */}
          <TabsContent value="tasks" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Create Task */}
              <Card>
                <CardHeader>
                  <CardTitle>Создать задание</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreateTask} className="space-y-4">
                    <div>
                      <Label htmlFor="task-title">Заголовок</Label>
                      <Input
                        id="task-title"
                        value={newTask.title}
                        onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                        placeholder="Название задания"
                        data-testid="input-task-title"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="task-description">Описание</Label>
                      <Textarea
                        id="task-description"
                        value={newTask.description}
                        onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                        placeholder="Описание задания"
                        data-testid="textarea-task-description"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="task-type">Тип задания</Label>
                      <Select 
                        value={newTask.type} 
                        onValueChange={(value) => setNewTask({ ...newTask, type: value })}
                      >
                        <SelectTrigger data-testid="select-task-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="channel_subscribe">Подписка на канал</SelectItem>
                          <SelectItem value="referral">Пригласить друзей</SelectItem>
                          <SelectItem value="case_opening">Открыть кейсы</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {newTask.type === 'channel_subscribe' && (
                      <div>
                        <Label htmlFor="task-url">URL канала</Label>
                        <Input
                          id="task-url"
                          value={newTask.url}
                          onChange={(e) => setNewTask({ ...newTask, url: e.target.value })}
                          placeholder="https://t.me/channel"
                          data-testid="input-task-url"
                        />
                      </div>
                    )}
                    
                    {(newTask.type === 'referral' || newTask.type === 'case_opening') && (
                      <div>
                        <Label htmlFor="task-target">Целевое значение</Label>
                        <Input
                          id="task-target"
                          type="number"
                          value={newTask.targetValue}
                          onChange={(e) => setNewTask({ ...newTask, targetValue: parseInt(e.target.value) })}
                          placeholder="1"
                          data-testid="input-task-target"
                        />
                      </div>
                    )}
                    
                    <div>
                      <Label htmlFor="task-reward">Награда (Stars)</Label>
                      <Input
                        id="task-reward"
                        type="number"
                        value={newTask.reward}
                        onChange={(e) => setNewTask({ ...newTask, reward: parseInt(e.target.value) })}
                        placeholder="50"
                        data-testid="input-task-reward"
                      />
                    </div>
                    
                    <Button type="submit" className="w-full" data-testid="button-create-task">
                      Создать задание
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Existing Tasks */}
              <Card>
                <CardHeader>
                  <CardTitle>Существующие задания</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {tasks.map((task: any) => (
                      <div key={task.id} className="border rounded-lg p-3" data-testid={`task-item-${task.id}`}>
                        <h4 className="font-medium">{task.title}</h4>
                        <p className="text-sm text-muted-foreground">{task.description}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded">
                            {task.type}
                          </span>
                          <span className="text-sm font-medium">⭐ {task.reward}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Promo Codes */}
          <TabsContent value="promo" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Промокоды</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Функция управления промокодами в разработке.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
