import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import BottomNavigation from "@/components/bottom-navigation";
import ProfileSection from "@/components/profile-section";
import CasesSection from "@/components/cases-section";
import LeadersSection from "@/components/leaders-section";
import TasksSection from "@/components/tasks-section";
import CaseOpeningModal from "@/components/case-opening-modal";
import bgPattern from "@assets/bg-DT3dyFN8_1756730199900.webp";

declare global {
  interface Window {
    Telegram?: {
      WebApp?: {
        ready: () => void;
        initDataUnsafe?: {
          user?: {
            id: string;
            username?: string;
            first_name?: string;
            last_name?: string;
          };
        };
        sendData: (data: string) => void;
        close: () => void;
      };
    };
  }
}

export default function Home() {
  const [activeSection, setActiveSection] = useState<'profile' | 'cases' | 'leaders' | 'tasks'>('profile');
  const [isOpeningCase, setIsOpeningCase] = useState(false);
  const [openingResult, setOpeningResult] = useState<any>(null);
  const [telegramUser, setTelegramUser] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize Telegram WebApp
  useEffect(() => {
    if (window.Telegram?.WebApp) {
      window.Telegram.WebApp.ready();
      const user = window.Telegram.WebApp.initDataUnsafe?.user;
      if (user) {
        setTelegramUser(user);
      } else {
        // For development - mock user
        setTelegramUser({
          id: "123456789",
          username: "testuser",
          first_name: "Test",
          last_name: "User"
        });
      }
    } else {
      // For development - mock user
      setTelegramUser({
        id: "123456789",
        username: "testuser",
        first_name: "Test",
        last_name: "User"
      });
    }
  }, []);

  // Get or create user
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['/api/user', telegramUser?.id],
    enabled: !!telegramUser?.id,
  });

  // Create user if doesn't exist
  const createUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      const response = await apiRequest('POST', '/api/user', userData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
  });

  // Auto-create user if not exists
  useEffect(() => {
    if (telegramUser && !userLoading && !user) {
      createUserMutation.mutate({
        telegramId: telegramUser.id,
        username: telegramUser.username,
        firstName: telegramUser.first_name,
        lastName: telegramUser.last_name,
      });
    }
  }, [telegramUser, user, userLoading]);

  // Get cases
  const { data: cases = [] } = useQuery({
    queryKey: ['/api/cases'],
    enabled: !!user,
  });

  // Open case mutation
  const openCaseMutation = useMutation({
    mutationFn: async ({ caseId, userId }: { caseId: string; userId: string }) => {
      const response = await apiRequest('POST', `/api/cases/${caseId}/open`, { userId });
      return response.json();
    },
    onSuccess: (data) => {
      setOpeningResult(data);
      setIsOpeningCase(true);
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      
      if (data.gift) {
        toast({
          title: "🎁 Подарок выпал!",
          description: `Вы выиграли подарок! Код: ${data.gift.giftCode}`,
        });
        
        // Notify Telegram about gift
        if (window.Telegram?.WebApp) {
          window.Telegram.WebApp.sendData(JSON.stringify({
            action: 'gift_won',
            userId: user?.id,
            giftCode: data.gift.giftCode,
            prizeName: data.prize.name
          }));
        }
      } else {
        toast({
          title: "🎉 Приз получен!",
          description: `Вы получили ${data.prize.value} re:coin!`,
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось открыть кейс",
        variant: "destructive",
      });
    },
  });

  const handleOpenCase = (caseId: string) => {
    if (!user?.id) return;
    openCaseMutation.mutate({ caseId, userId: user.id });
  };

  if (!telegramUser || userLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Загрузка...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen max-w-md mx-auto relative gaming-bg">
      {/* Background Pattern */}
      <div 
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `url(${bgPattern})`,
          backgroundSize: 'cover',
          backgroundRepeat: 'repeat',
        }}
      />
      
      {/* Header */}
      <header className="bg-card border-b border-border p-4 flex items-center justify-between relative z-10" data-testid="app-header">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
            <span className="text-accent-foreground font-bold text-lg" data-testid="user-initials">
              {user?.firstName?.[0] || 'U'}{user?.lastName?.[0] || ''}
            </span>
          </div>
          <div>
            <h1 className="text-lg font-bold" data-testid="app-title">Easy Gift</h1>
            <p className="text-xs text-muted-foreground" data-testid="user-display-name">
              {user?.firstName} {user?.lastName}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className="flex items-center space-x-1 bg-primary/20 px-2 py-1 rounded-full">
            <span className="text-primary">🪙</span>
            <span className="text-sm font-medium" data-testid="user-recoins">{user?.recoins || 0}</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 pb-20 relative z-10">
        {activeSection === 'profile' && <ProfileSection user={user} />}
        {activeSection === 'cases' && <CasesSection cases={cases} onOpenCase={handleOpenCase} user={user} />}
        {activeSection === 'leaders' && <LeadersSection />}
        {activeSection === 'tasks' && <TasksSection user={user} />}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation activeSection={activeSection} onSectionChange={setActiveSection} />

      {/* Case Opening Modal */}
      {isOpeningCase && (
        <CaseOpeningModal
          isOpen={isOpeningCase}
          onClose={() => {
            setIsOpeningCase(false);
            setOpeningResult(null);
          }}
          result={openingResult}
        />
      )}
    </div>
  );
}
