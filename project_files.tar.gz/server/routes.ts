import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertCaseSchema, insertPrizeSchema, insertTaskSchema, insertPromoCodeSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/user/:telegramId", async (req, res) => {
    try {
      const { telegramId } = req.params;
      const user = await storage.getUserByTelegramId(telegramId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/user", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Generate referral code
      userData.referralCode = `REF_${userData.telegramId}_${Date.now()}`;
      
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/user/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const user = await storage.updateUser(id, updates);
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Cases routes
  app.get("/api/cases", async (req, res) => {
    try {
      const cases = await storage.getCases();
      res.json(cases);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/cases/:id/prizes", async (req, res) => {
    try {
      const { id } = req.params;
      const prizes = await storage.getPrizesByCase(id);
      res.json(prizes);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Case opening
  app.post("/api/cases/:caseId/open", async (req, res) => {
    try {
      const { caseId } = req.params;
      const { userId } = req.body;
      
      const user = await storage.getUser(userId);
      const caseData = await storage.getCase(caseId);
      
      if (!user || !caseData) {
        return res.status(404).json({ message: "User or case not found" });
      }

      // Check if daily case
      if (caseData.isDaily) {
        const canUse = await storage.canUseDailyCase(userId);
        if (!canUse) {
          return res.status(400).json({ message: "Daily case already used today" });
        }
      } else {
        // Check if user has enough recoins
        if (user.recoins < caseData.cost) {
          return res.status(400).json({ message: "Insufficient recoins" });
        }
      }

      // Get case prizes and calculate random prize
      const prizes = await storage.getPrizesByCase(caseId);
      if (prizes.length === 0) {
        return res.status(400).json({ message: "No prizes available for this case" });
      }

      // Simple random selection based on chances
      const random = Math.random() * 100;
      let cumulative = 0;
      let selectedPrize = prizes[0];

      for (const prize of prizes) {
        cumulative += parseFloat(prize.chance);
        if (random <= cumulative) {
          selectedPrize = prize;
          break;
        }
      }

      // Create case opening record
      const opening = await storage.createCaseOpening(userId, caseId, selectedPrize.id);

      // Process prize
      let updatedUser = user;
      let giftCreated = null;

      if (selectedPrize.type === 'recoins') {
        // Award recoins
        updatedUser = await storage.updateUser(userId, {
          recoins: user.recoins + (selectedPrize.value || 0) - (caseData.isDaily ? 0 : caseData.cost),
          casesOpened: user.casesOpened + 1,
        });
      } else if (selectedPrize.type === 'gift') {
        // Create gift with unique code
        const giftCode = `${caseData.cost}${selectedPrize.giftNumber}`;
        giftCreated = await storage.createGift(userId, selectedPrize.id, giftCode);
        
        updatedUser = await storage.updateUser(userId, {
          recoins: user.recoins - (caseData.isDaily ? 0 : caseData.cost),
          casesOpened: user.casesOpened + 1,
        });
      }

      // Update daily case usage
      if (caseData.isDaily) {
        await storage.updateLastDailyCase(userId);
      }

      res.json({
        opening,
        prize: selectedPrize,
        gift: giftCreated,
        user: updatedUser,
      });
    } catch (error) {
      console.error('Case opening error:', error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Leaderboard
  app.get("/api/leaderboard/:type", async (req, res) => {
    try {
      const { type } = req.params;
      
      if (type !== 'recoins' && type !== 'cases') {
        return res.status(400).json({ message: "Invalid leaderboard type" });
      }
      
      const leaders = await storage.getUsersLeaderboard(type);
      res.json(leaders);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Tasks
  app.get("/api/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/user/:userId/tasks", async (req, res) => {
    try {
      const { userId } = req.params;
      const userTasks = await storage.getUserTasks(userId);
      res.json(userTasks);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/tasks/:taskId/complete", async (req, res) => {
    try {
      const { taskId } = req.params;
      const { userId } = req.body;
      
      const userTask = await storage.updateUserTask(userId, taskId, {
        completed: true,
        completedAt: new Date(),
      });
      
      res.json(userTask);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Promo codes
  app.post("/api/promo/use", async (req, res) => {
    try {
      const { userId, code } = req.body;
      
      const promoCode = await storage.getPromoCode(code);
      if (!promoCode) {
        return res.status(404).json({ message: "Promo code not found" });
      }
      
      if (!promoCode.isActive) {
        return res.status(400).json({ message: "Promo code is not active" });
      }
      
      if (promoCode.usedCount >= promoCode.usageLimit) {
        return res.status(400).json({ message: "Promo code usage limit reached" });
      }
      
      if (promoCode.expiresAt && new Date() > promoCode.expiresAt) {
        return res.status(400).json({ message: "Promo code has expired" });
      }
      
      const hasUsed = await storage.hasUsedPromoCode(userId, promoCode.id);
      if (hasUsed) {
        return res.status(400).json({ message: "Promo code already used" });
      }
      
      // Use promo code
      await storage.usePromoCode(userId, promoCode.id);
      
      // Update user recoins
      const user = await storage.getUser(userId);
      if (user) {
        const updatedUser = await storage.updateUser(userId, {
          recoins: user.recoins + promoCode.reward,
        });
        res.json({ message: "Promo code used successfully", user: updatedUser });
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin routes (protected)
  app.post("/api/admin/cases", async (req, res) => {
    try {
      const caseData = insertCaseSchema.parse(req.body);
      const newCase = await storage.createCase(caseData);
      res.json(newCase);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid case data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/prizes", async (req, res) => {
    try {
      const prizeData = insertPrizeSchema.parse(req.body);
      const prize = await storage.createPrize(prizeData);
      res.json(prize);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid prize data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/admin/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Telegram Stars purchase simulation
  app.post("/api/stars/purchase", async (req, res) => {
    try {
      const { userId, starsAmount } = req.body;
      const recoinsAmount = starsAmount * 5; // 1 star = 5 recoins
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, {
        stars: user.stars + starsAmount,
        recoins: user.recoins + recoinsAmount,
      });
      
      res.json({ message: "Stars purchased successfully", user: updatedUser });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
