import { 
  users, cases, prizes, caseOpenings, gifts, tasks, userTasks, promoCodes, promoCodeUsage, starPurchases,
  type User, type InsertUser, type Case, type InsertCase, type Prize, type InsertPrize,
  type CaseOpening, type Gift, type Task, type InsertTask, type UserTask, type PromoCode, type InsertPromoCode
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, lt, gt } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByTelegramId(telegramId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  getUsersLeaderboard(type: 'recoins' | 'cases'): Promise<User[]>;

  // Case methods
  getCases(): Promise<Case[]>;
  getCase(id: string): Promise<Case | undefined>;
  createCase(caseData: InsertCase): Promise<Case>;
  updateCase(id: string, updates: Partial<Case>): Promise<Case>;

  // Prize methods
  getPrizesByCase(caseId: string): Promise<Prize[]>;
  createPrize(prizeData: InsertPrize): Promise<Prize>;
  updatePrize(id: string, updates: Partial<Prize>): Promise<Prize>;

  // Case opening methods
  createCaseOpening(userId: string, caseId: string, prizeId: string): Promise<CaseOpening>;
  getUserCaseOpenings(userId: string): Promise<CaseOpening[]>;

  // Gift methods
  createGift(userId: string, prizeId: string, giftCode: string): Promise<Gift>;
  getUserGifts(userId: string): Promise<Gift[]>;

  // Task methods
  getTasks(): Promise<Task[]>;
  createTask(taskData: InsertTask): Promise<Task>;
  updateTask(id: string, updates: Partial<Task>): Promise<Task>;
  getUserTasks(userId: string): Promise<UserTask[]>;
  updateUserTask(userId: string, taskId: string, updates: Partial<UserTask>): Promise<UserTask>;

  // Promo code methods
  getPromoCode(code: string): Promise<PromoCode | undefined>;
  usePromoCode(userId: string, promoCodeId: string): Promise<void>;
  hasUsedPromoCode(userId: string, promoCodeId: string): Promise<boolean>;

  // Daily case check
  canUseDailyCase(userId: string): Promise<boolean>;
  updateLastDailyCase(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByTelegramId(telegramId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.telegramId, telegramId));
    return user || undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async getUsersLeaderboard(type: 'recoins' | 'cases'): Promise<User[]> {
    const orderBy = type === 'recoins' ? desc(users.recoins) : desc(users.casesOpened);
    return await db.select().from(users).orderBy(orderBy).limit(50);
  }

  // Case methods
  async getCases(): Promise<Case[]> {
    return await db.select().from(cases).where(eq(cases.isActive, true)).orderBy(cases.cost);
  }

  async getCase(id: string): Promise<Case | undefined> {
    const [caseData] = await db.select().from(cases).where(eq(cases.id, id));
    return caseData || undefined;
  }

  async createCase(caseData: InsertCase): Promise<Case> {
    const [newCase] = await db.insert(cases).values(caseData).returning();
    return newCase;
  }

  async updateCase(id: string, updates: Partial<Case>): Promise<Case> {
    const [updatedCase] = await db.update(cases).set(updates).where(eq(cases.id, id)).returning();
    return updatedCase;
  }

  // Prize methods
  async getPrizesByCase(caseId: string): Promise<Prize[]> {
    return await db.select().from(prizes).where(eq(prizes.caseId, caseId));
  }

  async createPrize(prizeData: InsertPrize): Promise<Prize> {
    const [prize] = await db.insert(prizes).values(prizeData).returning();
    return prize;
  }

  async updatePrize(id: string, updates: Partial<Prize>): Promise<Prize> {
    const [prize] = await db.update(prizes).set(updates).where(eq(prizes.id, id)).returning();
    return prize;
  }

  // Case opening methods
  async createCaseOpening(userId: string, caseId: string, prizeId: string): Promise<CaseOpening> {
    const [opening] = await db.insert(caseOpenings).values({
      userId,
      caseId,
      prizeId,
    }).returning();
    return opening;
  }

  async getUserCaseOpenings(userId: string): Promise<CaseOpening[]> {
    return await db.select().from(caseOpenings).where(eq(caseOpenings.userId, userId)).orderBy(desc(caseOpenings.openedAt));
  }

  // Gift methods
  async createGift(userId: string, prizeId: string, giftCode: string): Promise<Gift> {
    const [gift] = await db.insert(gifts).values({
      userId,
      prizeId,
      giftCode,
    }).returning();
    return gift;
  }

  async getUserGifts(userId: string): Promise<Gift[]> {
    return await db.select().from(gifts).where(eq(gifts.userId, userId)).orderBy(desc(gifts.createdAt));
  }

  // Task methods
  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks).where(eq(tasks.isActive, true));
  }

  async createTask(taskData: InsertTask): Promise<Task> {
    const [task] = await db.insert(tasks).values(taskData).returning();
    return task;
  }

  async updateTask(id: string, updates: Partial<Task>): Promise<Task> {
    const [task] = await db.update(tasks).set(updates).where(eq(tasks.id, id)).returning();
    return task;
  }

  async getUserTasks(userId: string): Promise<UserTask[]> {
    return await db.select().from(userTasks).where(eq(userTasks.userId, userId));
  }

  async updateUserTask(userId: string, taskId: string, updates: Partial<UserTask>): Promise<UserTask> {
    const [userTask] = await db.update(userTasks)
      .set(updates)
      .where(and(eq(userTasks.userId, userId), eq(userTasks.taskId, taskId)))
      .returning();
    return userTask;
  }

  // Promo code methods
  async getPromoCode(code: string): Promise<PromoCode | undefined> {
    const [promoCode] = await db.select().from(promoCodes).where(eq(promoCodes.code, code));
    return promoCode || undefined;
  }

  async usePromoCode(userId: string, promoCodeId: string): Promise<void> {
    await db.transaction(async (tx) => {
      await tx.insert(promoCodeUsage).values({ userId, promoCodeId });
      await tx.update(promoCodes)
        .set({ usedCount: sql`${promoCodes.usedCount} + 1` })
        .where(eq(promoCodes.id, promoCodeId));
    });
  }

  async hasUsedPromoCode(userId: string, promoCodeId: string): Promise<boolean> {
    const [usage] = await db.select().from(promoCodeUsage)
      .where(and(eq(promoCodeUsage.userId, userId), eq(promoCodeUsage.promoCodeId, promoCodeId)));
    return !!usage;
  }

  // Daily case check
  async canUseDailyCase(userId: string): Promise<boolean> {
    const [user] = await db.select({ lastDailyCase: users.lastDailyCase })
      .from(users)
      .where(eq(users.id, userId));
    
    if (!user?.lastDailyCase) return true;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return user.lastDailyCase < today;
  }

  async updateLastDailyCase(userId: string): Promise<void> {
    await db.update(users)
      .set({ lastDailyCase: new Date() })
      .where(eq(users.id, userId));
  }
}

export const storage = new DatabaseStorage();
