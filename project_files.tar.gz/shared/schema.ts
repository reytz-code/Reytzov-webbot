import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  recoins: integer("recoins").default(0).notNull(),
  stars: integer("stars").default(0).notNull(),
  referralCode: text("referral_code").unique(),
  referredBy: varchar("referred_by"),
  totalReferrals: integer("total_referrals").default(0).notNull(),
  casesOpened: integer("cases_opened").default(0).notNull(),
  lastDailyCase: timestamp("last_daily_case"),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").default(sql`NOW()`).notNull(),
});

export const cases = pgTable("cases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  cost: integer("cost").notNull(),
  image: text("image"),
  isDaily: boolean("is_daily").default(false).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").default(sql`NOW()`).notNull(),
});

export const prizes = pgTable("prizes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").references(() => cases.id).notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'recoins', 'gift'
  value: integer("value"), // for recoins
  giftNumber: integer("gift_number"), // for gifts
  chance: decimal("chance", { precision: 5, scale: 2 }).notNull(), // probability out of 100
  image: text("image"),
  createdAt: timestamp("created_at").default(sql`NOW()`).notNull(),
});

export const caseOpenings = pgTable("case_openings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  caseId: varchar("case_id").references(() => cases.id).notNull(),
  prizeId: varchar("prize_id").references(() => prizes.id).notNull(),
  openedAt: timestamp("opened_at").default(sql`NOW()`).notNull(),
});

export const gifts = pgTable("gifts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  prizeId: varchar("prize_id").references(() => prizes.id).notNull(),
  giftCode: text("gift_code").notNull().unique(), // format: caseId + giftNumber
  claimed: boolean("claimed").default(false).notNull(),
  createdAt: timestamp("created_at").default(sql`NOW()`).notNull(),
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // 'channel_subscribe', 'referral', 'case_opening'
  url: text("url"), // for channel subscribe tasks
  targetValue: integer("target_value"), // for referral/case opening tasks
  reward: integer("reward").notNull(), // stars reward
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").default(sql`NOW()`).notNull(),
});

export const userTasks = pgTable("user_tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  taskId: varchar("task_id").references(() => tasks.id).notNull(),
  completed: boolean("completed").default(false).notNull(),
  progress: integer("progress").default(0).notNull(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").default(sql`NOW()`).notNull(),
});

export const promoCodes = pgTable("promo_codes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  code: text("code").notNull().unique(),
  reward: integer("reward").notNull(), // recoins
  usageLimit: integer("usage_limit").default(1).notNull(),
  usedCount: integer("used_count").default(0).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").default(sql`NOW()`).notNull(),
});

export const promoCodeUsage = pgTable("promo_code_usage", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  promoCodeId: varchar("promo_code_id").references(() => promoCodes.id).notNull(),
  usedAt: timestamp("used_at").default(sql`NOW()`).notNull(),
});

export const starPurchases = pgTable("star_purchases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  starsAmount: integer("stars_amount").notNull(),
  recoinsAmount: integer("recoins_amount").notNull(),
  telegramPaymentId: text("telegram_payment_id"),
  status: text("status").default("pending").notNull(), // 'pending', 'completed', 'failed'
  createdAt: timestamp("created_at").default(sql`NOW()`).notNull(),
});

// Relations  
export const usersRelations = relations(users, ({ many, one }) => ({
  referrals: many(users, { relationName: "referral" }),
  referrer: one(users, {
    fields: [users.referredBy],
    references: [users.id],
    relationName: "referral",
  }),
  caseOpenings: many(caseOpenings),
  gifts: many(gifts),
  userTasks: many(userTasks),
  promoCodeUsages: many(promoCodeUsage),
  starPurchases: many(starPurchases),
}));

export const casesRelations = relations(cases, ({ many }) => ({
  prizes: many(prizes),
  caseOpenings: many(caseOpenings),
}));

export const prizesRelations = relations(prizes, ({ one, many }) => ({
  case: one(cases, {
    fields: [prizes.caseId],
    references: [cases.id],
  }),
  caseOpenings: many(caseOpenings),
  gifts: many(gifts),
}));

export const caseOpeningsRelations = relations(caseOpenings, ({ one }) => ({
  user: one(users, {
    fields: [caseOpenings.userId],
    references: [users.id],
  }),
  case: one(cases, {
    fields: [caseOpenings.caseId],
    references: [cases.id],
  }),
  prize: one(prizes, {
    fields: [caseOpenings.prizeId],
    references: [prizes.id],
  }),
}));

export const giftsRelations = relations(gifts, ({ one }) => ({
  user: one(users, {
    fields: [gifts.userId],
    references: [users.id],
  }),
  prize: one(prizes, {
    fields: [gifts.prizeId],
    references: [prizes.id],
  }),
}));

export const tasksRelations = relations(tasks, ({ many }) => ({
  userTasks: many(userTasks),
}));

export const userTasksRelations = relations(userTasks, ({ one }) => ({
  user: one(users, {
    fields: [userTasks.userId],
    references: [users.id],
  }),
  task: one(tasks, {
    fields: [userTasks.taskId],
    references: [tasks.id],
  }),
}));

export const promoCodesRelations = relations(promoCodes, ({ many }) => ({
  usages: many(promoCodeUsage),
}));

export const promoCodeUsageRelations = relations(promoCodeUsage, ({ one }) => ({
  user: one(users, {
    fields: [promoCodeUsage.userId],
    references: [users.id],
  }),
  promoCode: one(promoCodes, {
    fields: [promoCodeUsage.promoCodeId],
    references: [promoCodes.id],
  }),
}));

export const starPurchasesRelations = relations(starPurchases, ({ one }) => ({
  user: one(users, {
    fields: [starPurchases.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertCaseSchema = createInsertSchema(cases).omit({
  id: true,
  createdAt: true,
});

export const insertPrizeSchema = createInsertSchema(prizes).omit({
  id: true,
  createdAt: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
});

export const insertPromoCodeSchema = createInsertSchema(promoCodes).omit({
  id: true,
  createdAt: true,
  usedCount: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Case = typeof cases.$inferSelect;
export type InsertCase = z.infer<typeof insertCaseSchema>;
export type Prize = typeof prizes.$inferSelect;
export type InsertPrize = z.infer<typeof insertPrizeSchema>;
export type CaseOpening = typeof caseOpenings.$inferSelect;
export type Gift = typeof gifts.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type UserTask = typeof userTasks.$inferSelect;
export type PromoCode = typeof promoCodes.$inferSelect;
export type InsertPromoCode = z.infer<typeof insertPromoCodeSchema>;
export type StarPurchase = typeof starPurchases.$inferSelect;
