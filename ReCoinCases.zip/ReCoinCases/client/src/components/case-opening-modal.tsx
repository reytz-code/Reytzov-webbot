import { useEffect, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface CaseOpeningModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: any;
}

export default function CaseOpeningModal({ isOpen, onClose, result }: CaseOpeningModalProps) {
  const [isAnimating, setIsAnimating] = useState(false);
  const [showResult, setShowResult] = useState(false);

  // Animation sequence
  useEffect(() => {
    if (isOpen && result) {
      setIsAnimating(true);
      setShowResult(false);
      
      // Show result after animation
      const timer = setTimeout(() => {
        setIsAnimating(false);
        setShowResult(true);
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [isOpen, result]);

  // Generate random items for animation
  const generateAnimationItems = () => {
    const items = [];
    const icons = ['🎁', '💎', '🏆', '⭐', '🪙', '🎯', '🎪', '👑', '💰', '🔥', '🎮', '🚀', '💎', '🌟', '🏅', '💸', '⚡', '🔮', '💍', '👾'];
    const colors = [
      'bg-yellow-500',
      'bg-purple-500',
      'bg-blue-500',
      'bg-green-500',
      'bg-red-500',
      'bg-pink-500',
      'bg-cyan-500',
      'bg-orange-500',
      'bg-indigo-500',
      'bg-teal-500'
    ];

    // Generate more items for smoother animation
    for (let i = 0; i < 50; i++) {
      items.push({
        id: i,
        icon: icons[Math.floor(Math.random() * icons.length)],
        color: colors[Math.floor(Math.random() * colors.length)],
        isWinning: i === 25, // Middle item will be the winning one
      });
    }
    return items;
  };

  const animationItems = generateAnimationItems();

  const getPrizeIcon = (prize: any) => {
    if (prize?.type === 'gift') return '🎁';
    if (prize?.type === 'recoins') {
      const value = prize.value || 0;
      if (value >= 100) return '💎';
      if (value >= 50) return '🏆';
      return '🪙';
    }
    return '🎁';
  };

  const getPrizeColor = (prize: any) => {
    if (prize?.type === 'gift') return 'from-purple-500 to-pink-500';
    if (prize?.type === 'recoins') {
      const value = prize.value || 0;
      if (value >= 100) return 'from-blue-500 to-cyan-500';
      if (value >= 50) return 'from-yellow-500 to-orange-500';
      return 'from-green-500 to-emerald-500';
    }
    return 'from-purple-500 to-pink-500';
  };

  if (!result) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-card border-border p-6 mx-4 w-full max-w-sm" data-testid="case-opening-modal">
        <div className="text-center">
          <h3 className="text-xl font-bold mb-4" data-testid="modal-title">
            {isAnimating ? 'Открытие кейса...' : 'Поздравляем!'}
          </h3>

          {/* Animation Container */}
          <div className="relative overflow-hidden h-24 mb-4 rounded-lg border-2 border-primary bg-muted">
            {isAnimating ? (
              <>
                {/* Scrolling Animation */}
                <div className="flex absolute top-0 left-0 h-full animate-case-scroll">
                  {animationItems.map((item) => (
                    <div
                      key={item.id}
                      className={`w-20 h-20 mx-2 mt-2 ${item.color} rounded-lg flex items-center justify-center flex-shrink-0 shadow-lg`}
                    >
                      <span className="text-2xl">{item.icon}</span>
                    </div>
                  ))}
                </div>
                {/* Center indicator line */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-16 bg-primary z-10"></div>
              </>
            ) : (
              /* Final Result */
              <div className="flex items-center justify-center h-full">
                <div className={`w-20 h-20 bg-gradient-to-br ${getPrizeColor(result.prize)} rounded-lg flex items-center justify-center shadow-xl animate-pulse-glow`}>
                  <span className="text-3xl">{getPrizeIcon(result.prize)}</span>
                </div>
              </div>
            )}
          </div>

          {/* Result Information */}
          {showResult && (
            <div className="space-y-3" data-testid="result-info">
              <div className="text-center">
                <h4 className="font-bold text-lg" data-testid="prize-name">
                  {result.prize?.name || 'Приз'}
                </h4>
                
                {result.prize?.type === 'recoins' ? (
                  <div className="flex items-center justify-center space-x-2 mt-2">
                    <span className="text-2xl font-bold text-primary" data-testid="prize-value">
                      +{result.prize.value}
                    </span>
                    <span className="text-primary">🪙</span>
                  </div>
                ) : (
                  <div className="mt-2">
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700" data-testid="gift-badge">
                      🎁 Подарок
                    </Badge>
                    {result.gift && (
                      <p className="text-sm text-muted-foreground mt-1" data-testid="gift-code">
                        Код: {result.gift.giftCode}
                      </p>
                    )}
                  </div>
                )}
              </div>

              {result.gift && (
                <div className="bg-accent/20 rounded-lg p-3 border border-accent">
                  <p className="text-sm text-center" data-testid="gift-message">
                    🎉 Вы выиграли подарок! Администратор свяжется с вами для выдачи.
                  </p>
                </div>
              )}

              {/* Updated Balance */}
              {result.user && (
                <div className="bg-muted/50 rounded-lg p-3">
                  <p className="text-sm text-muted-foreground text-center mb-1">Ваш баланс</p>
                  <div className="flex items-center justify-center space-x-2">
                    <span className="font-bold" data-testid="updated-balance">
                      {result.user.recoins}
                    </span>
                    <span className="text-primary">🪙</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Close Button */}
          <Button 
            className="w-full mt-4" 
            onClick={onClose}
            disabled={isAnimating}
            data-testid="close-modal-button"
          >
            {isAnimating ? 'Ожидание...' : 'Закрыть'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
