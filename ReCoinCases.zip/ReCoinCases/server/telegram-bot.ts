import TelegramBot from 'node-telegram-bot-api';
import { storage } from './storage';

const BOT_TOKEN = process.env.BOT_TOKEN || '8356357930:AAGLYEB09IvRU2RBfOIYxMqAxXBNylTbciM';
const WEBAPP_URL = process.env.WEBAPP_URL || 'https://your-domain.com';
const CHANNEL_URL = '@budkareytzov';
const ADMIN_USERNAME = '@oxoxece';

export class TelegramBotService {
  private bot: TelegramBot;

  constructor() {
    this.bot = new TelegramBot(BOT_TOKEN, { polling: true });
    this.setupCommands();
    this.setupCallbacks();
  }

  private setupCommands() {
    // Start command
    this.bot.onText(/\/start(?:\s+(.+))?/, async (msg, match) => {
      const chatId = msg.chat.id;
      const referralCode = match?.[1];
      
      try {
        // Check if user exists
        let user = await storage.getUserByTelegramId(msg.from?.id.toString() || '');
        
        if (!user && msg.from) {
          // Create new user
          const userData = {
            telegramId: msg.from.id.toString(),
            username: msg.from.username,
            firstName: msg.from.first_name,
            lastName: msg.from.last_name,
          };
          
          // Handle referral
          if (referralCode) {
            const referrer = await storage.getUserByTelegramId(referralCode);
            if (referrer) {
              userData.referredBy = referrer.id;
              // Award referral bonus
              await storage.updateUser(referrer.id, {
                recoins: referrer.recoins + 25,
                totalReferrals: referrer.totalReferrals + 1,
              });
            }
          }
          
          user = await storage.createUser(userData);
        }

        const keyboard = {
          reply_markup: {
            inline_keyboard: [
              [{ text: '🎮 Открыть Easy Gift', web_app: { url: WEBAPP_URL } }],
              [{ text: '📢 Наш канал', url: 'https://t.me/budkareytzov' }],
              [{ text: '💬 Поддержка', url: 'https://t.me/oxoxece' }]
            ]
          }
        };

        await this.bot.sendMessage(chatId, 
          `🎮 Добро пожаловать в Easy Gift!\n\n` +
          `💰 Открывай кейсы и получай призы!\n` +
          `⭐ Покупай re:coin за Telegram Stars\n` +
          `🎁 Выигрывай реальные подарки\n\n` +
          `Нажми на кнопку ниже, чтобы начать игру!`, 
          keyboard
        );
      } catch (error) {
        console.error('Start command error:', error);
        await this.bot.sendMessage(chatId, 'Произошла ошибка. Попробуйте позже.');
      }
    });

    // Help command
    this.bot.onText(/\/help/, async (msg) => {
      const chatId = msg.chat.id;
      
      const helpText = `
🎮 Easy Gift - Справка

🎯 Как играть:
• Получай ежедневный бесплатный кейс
• Покупай re:coin за Telegram Stars (1⭐ = 5🪙)
• Открывай кейсы и получай призы
• Выполняй задания для получения звезд

💎 Типы кейсов:
• Ежедневный (бесплатно) - 1-25 re:coin
• Базовый (25🪙) - до 50 re:coin + подарки
• Редкий (100🪙) - больше призов
• Элитный (250🪙) - редкие подарки
• Легендарный (500🪙) - эпические призы
• Королевский (1000🪙) - максимальные награды

🎁 Подарки имеют уникальные номера и выдаются администратором

👥 Реферальная система:
• Приглашай друзей и получай 25🪙 за каждого

Команды:
/start - Запуск бота
/help - Эта справка
/balance - Текущий баланс
      `;
      
      await this.bot.sendMessage(chatId, helpText);
    });

    // Balance command
    this.bot.onText(/\/balance/, async (msg) => {
      const chatId = msg.chat.id;
      
      try {
        const user = await storage.getUserByTelegramId(msg.from?.id.toString() || '');
        
        if (!user) {
          await this.bot.sendMessage(chatId, 'Пользователь не найден. Используйте /start');
          return;
        }

        await this.bot.sendMessage(chatId, 
          `💰 Ваш баланс:\n` +
          `🪙 re:coin: ${user.recoins}\n` +
          `⭐ Stars: ${user.stars}\n` +
          `📦 Кейсов открыто: ${user.casesOpened}\n` +
          `👥 Рефералов: ${user.totalReferrals}`
        );
      } catch (error) {
        console.error('Balance command error:', error);
        await this.bot.sendMessage(chatId, 'Произошла ошибка при получении баланса.');
      }
    });
  }

  private setupCallbacks() {
    // Handle web app data
    this.bot.on('web_app_data', async (msg) => {
      const chatId = msg.chat.id;
      const data = JSON.parse(msg.web_app?.data || '{}');
      
      // Handle different web app actions
      switch (data.action) {
        case 'gift_won':
          await this.notifyGiftWon(data.userId, data.giftCode, data.prizeName);
          break;
        case 'referral_share':
          await this.handleReferralShare(chatId, data.referralCode);
          break;
      }
    });
  }

  private async notifyGiftWon(userId: string, giftCode: string, prizeName: string) {
    try {
      const user = await storage.getUser(userId);
      if (!user) return;

      // Notify admin
      const adminMessage = `
🎁 НОВЫЙ ВЫИГРЫШ ПОДАРКА!

👤 Пользователь: ${user.firstName || ''} ${user.lastName || ''}
📱 Username: @${user.username || 'не указан'}
🆔 Telegram ID: ${user.telegramId}
🎁 Подарок: ${prizeName}
🔢 Код подарка: ${giftCode}

Свяжитесь с пользователем для выдачи подарка.
      `;

      // Send to admin (you'll need to get admin's chat ID)
      // await this.bot.sendMessage(ADMIN_CHAT_ID, adminMessage);
      
      // Notify user
      await this.bot.sendMessage(parseInt(user.telegramId), 
        `🎉 Поздравляем! Вы выиграли подарок!\n\n` +
        `🎁 Приз: ${prizeName}\n` +
        `🔢 Код: ${giftCode}\n\n` +
        `Администратор свяжется с вами для выдачи подарка. ` +
        `Для связи: ${ADMIN_USERNAME}`
      );
    } catch (error) {
      console.error('Gift notification error:', error);
    }
  }

  private async handleReferralShare(chatId: number, referralCode: string) {
    const referralLink = `https://t.me/your_bot_username?start=${referralCode}`;
    const shareText = `
🎮 Присоединяйся к Easy Gift!

Открывай кейсы, получай призы и зарабатывай re:coin!

🎁 По твоей ссылке друг получит бонус
💰 Ты получишь 25 re:coin за каждого друга

${referralLink}
    `;

    await this.bot.sendMessage(chatId, shareText, {
      reply_markup: {
        inline_keyboard: [
          [{ text: '📤 Поделиться', switch_inline_query: shareText }]
        ]
      }
    });
  }

  public async sendGiftNotification(adminChatId: number, userInfo: any, giftInfo: any) {
    try {
      const message = `
🎁 ВЫПАЛ ПОДАРОК!

👤 Пользователь: ${userInfo.firstName || ''} ${userInfo.lastName || ''}
📱 @${userInfo.username || 'не указан'}
🆔 ID: ${userInfo.telegramId}
🎁 Подарок: ${giftInfo.name}
🔢 Код: ${giftInfo.code}
      `;

      await this.bot.sendMessage(adminChatId, message);
    } catch (error) {
      console.error('Gift notification error:', error);
    }
  }
}

// Export singleton instance
export const telegramBot = new TelegramBotService();
